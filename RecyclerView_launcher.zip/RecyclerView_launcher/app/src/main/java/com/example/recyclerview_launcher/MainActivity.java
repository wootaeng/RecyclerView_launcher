package com.example.recyclerview_launcher;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.LinearLayout;

import java.util.ArrayList;
import java.util.List;


public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        final PackageManager pm = getPackageManager();
        List<ApplicationInfo> packages = pm.getInstalledApplications(PackageManager.GET_META_DATA);
        List<ApplicationInfo> list = new ArrayList<>();

        for (ApplicationInfo packageInfo : packages){
            Log.d("ApplicationInfo", "Installed package : " + packageInfo.packageName);
            Log.d("ApplicationInfo", "Source dir : " + packageInfo.sourceDir);
            Log.d("ApplicationInfo", "Launch Activity :" + pm.getLaunchIntentForPackage(packageInfo.packageName));
        }

        recyclerView = (RecyclerView)findViewById(R.id.recyclerView);

        LinearLayoutManager layoutManager = new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL, false);
        recyclerView.setLayoutManager(layoutManager);

//        SingerAdapter adapter = new SingerAdapter(getApplicationContext());
//        adapter.addItem((new SingerItem("이우석","010-0000-0000")));
//        adapter.addItem((new SingerItem("이채연","010-0000-0000")));
//        adapter.addItem((new SingerItem("이종현","010-0000-0000")));
//        recyclerView.setAdapter(adapter);

        ((RecyclerView)findViewById(R.id.recyclerView)).setAdapter(new AppAdapter(pm,list));
        ((RecyclerView)findViewById(R.id.recyclerView)).setHasFixedSize(true);
        ((RecyclerView)findViewById(R.id.recyclerView)).setLayoutManager(new LinearLayoutManager(this));
    }
}