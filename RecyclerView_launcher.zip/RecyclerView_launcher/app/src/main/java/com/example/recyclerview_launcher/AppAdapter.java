package com.example.recyclerview_launcher;


import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class AppAdapter extends RecyclerView.Adapter<AppAdapter.ItemViewHolder> {


    private List<ApplicationInfo> items;
    private PackageManager pm ;
    public AppAdapter(PackageManager pm,List<ApplicationInfo> items) {
        this.items = items;
        this.pm = pm;
    }

    public void clear(){
        this.items.clear();
    }
    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_app_item, parent, false);
        return new ItemViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ItemViewHolder holder, int position) {
        holder.onBind(items.get(position));
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    class ItemViewHolder extends RecyclerView.ViewHolder {

        private RecyclerAppItemBinding binding;

        ItemViewHolder(View itemView) {
            super(itemView);
            binding = DataBindingUtil.bind(itemView);
        }

        void onBind(ApplicationInfo info) {
            binding.title.setText(pm.getApplicationLabel(info));
            binding.name.setText(info.packageName);
            try {
                binding.img.setBackground(pm.getApplicationIcon(info.packageName));
            } catch (PackageManager.NameNotFoundException e) {
                e.printStackTrace();
            }


        }

    }




//    Context context;
//
//    ArrayList<SingerItem> items = new ArrayList<SingerItem>();
//
//
//    public AppAdapter(Context context){
//        this.context = context;
//    }
//
//    @NonNull
//    @org.jetbrains.annotations.NotNull
//    @Override
//    public ViewHolder onCreateViewHolder(@NonNull @org.jetbrains.annotations.NotNull ViewGroup parent, int viewType) {
//        LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
//        View itemView = inflater.inflate(R.layout.singer_item, parent, false);
//
//        return new ViewHolder(itemView);
//    }
//
//
//
//    @Override
//    public void onBindViewHolder(@NonNull @org.jetbrains.annotations.NotNull AppAdapter.ViewHolder holder, int position) {
//        SingerItem item = items.get(position);
//        holder.setItem(item);
//    }
//
//    @Override
//    public int getItemCount() {
//        return items.size();
//    }
//
//    public void addItem(SingerItem item){
//        items.add(item);
//    }
//    public void additems(ArrayList<SingerItem> items){
//        this.items = items;
//    }
//    public SingerItem getItem(int position){
//        return items.get(position);
//    }
//
//
//    static class ViewHolder extends RecyclerView.ViewHolder {
//
//        TextView textView;
//        TextView textView2;
//
//        public ViewHolder(@NonNull @org.jetbrains.annotations.NotNull View itemView) {
//            super(itemView);
//
//            textView = (TextView) itemView.findViewById(R.id.textView);
//            textView2 = (TextView) itemView.findViewById(R.id.textView2);
//        }
//
//        public void setItem(SingerItem item){
//            textView.setText(item.getName());
//            textView2.setText(item.getMobile());
//        }
//    }
}
